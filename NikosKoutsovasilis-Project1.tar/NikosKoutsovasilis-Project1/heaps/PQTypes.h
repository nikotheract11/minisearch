/* This is the file �PQTypes.h� */
#include "../trie.h"
typedef struct {
           int Count;
           pair **ItemArray;
        } PriorityQueue;
